import tkinter as tk
from tkinter import ttk, messagebox as mess, simpledialog as tsd
import cv2, os, csv, numpy as np
from PIL import Image
import pandas as pd
import datetime, time

def assure_path_exists(path):
    if not os.path.exists(path):
        os.makedirs(path)

def tick():
    clock.config(text=time.strftime('%H:%M:%S'))
    clock.after(200, tick)

def contact():
    mess.showinfo('Contact us', "Please contact us at: shubhamkumar8180323@gmail.com")

def check_haarcascadefile():
    if not os.path.isfile("haarcascade_frontalface_default.xml"):
        mess.showerror('Missing File', 'haarcascade_frontalface_default.xml not found')
        window.destroy()

# --- Password Functions ---
def save_pass():
    assure_path_exists("TrainingImageLabel")
    psd_path = os.path.join("TrainingImageLabel", "psd.txt")
    if os.path.isfile(psd_path):
        with open(psd_path, 'r') as tf:
            key = tf.read().strip()
    else:
        new_pas = tsd.askstring('Set Password', 'Enter new password', show='*')
        if not new_pas:
            mess.showerror('Error', 'No password entered')
            return
        with open(psd_path, 'w') as tf:
            tf.write(new_pas)
        mess.showinfo('Success', 'Password set')
        return

    if old.get() != key:
        mess.showerror('Error', 'Wrong old password')
        return
    if new.get() != nnew.get():
        mess.showerror('Error', 'New passwords do not match')
        return

    with open(psd_path, 'w') as tf:
        tf.write(new.get())
    mess.showinfo('Success', 'Password changed')
    master.destroy()

def change_pass():
    global master, old, new, nnew
    master = tk.Toplevel(window)
    master.geometry("400x160")
    master.title("Change Password")
    master.configure(bg="white")

    tk.Label(master, text='Old Password', bg='white').place(x=10,y=10)
    old = tk.Entry(master, show='*', width=25)
    old.place(x=150,y=10)

    tk.Label(master, text='New Password', bg='white').place(x=10,y=45)
    new = tk.Entry(master, show='*', width=25)
    new.place(x=150,y=45)

    tk.Label(master, text='Confirm New', bg='white').place(x=10,y=80)
    nnew = tk.Entry(master, show='*', width=25)
    nnew.place(x=150,y=80)

    tk.Button(master, text="Save", command=save_pass).place(x=50,y=120)
    tk.Button(master, text="Cancel", command=master.destroy).place(x=220,y=120)

def psw():
    assure_path_exists("TrainingImageLabel")
    psd_path = os.path.join("TrainingImageLabel", "psd.txt")
    if not os.path.isfile(psd_path):
        new_pas = tsd.askstring('Set Password', 'Enter new password', show='*')
        if not new_pas:
            mess.showerror('Error', 'Password not set')
            return
        with open(psd_path, 'w') as tf:
            tf.write(new_pas)
        mess.showinfo('Success', 'Password registered')
        return

    with open(psd_path, 'r') as tf:
        key = tf.read().strip()
    pwd = tsd.askstring('Password', 'Enter password', show='*')
    if pwd == key:
        TrainImages()
    elif pwd is not None:
        mess.showerror('Error', 'Wrong password')

# --- Student Registration ---
def clear_entries():
    txt.delete(0, 'end')
    txt2.delete(0, 'end')
    message1.config(text="1) Take Images >>> 2) Save Profile")

def TakeImages():
    check_haarcascadefile()
    assure_path_exists("TrainingImage")
    assure_path_exists("StudentDetails")

    Id = txt.get().strip()
    name = txt2.get().strip()
    if not Id.isdigit() or not name.replace(' ','').isalpha():
        mess.showerror('Error', 'Enter valid ID and Name')
        return

    csv_path = os.path.join("StudentDetails", "StudentDetails.csv")
    serial = 1
    if os.path.isfile(csv_path):
        df = pd.read_csv(csv_path)
        serial = df.shape[0] + 1
    else:
        df = pd.DataFrame(columns=['SERIAL NO.', 'ID', 'NAME'])
        df.to_csv(csv_path, index=False)

    cam = cv2.VideoCapture(0)
    detector = cv2.CascadeClassifier("haarcascade_frontalface_default.xml")
    sampleNum = 0

    while True:
        ret, img = cam.read()
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        for (x, y, w, h) in detector.detectMultiScale(gray, 1.3, 5):
            sampleNum += 1
            fn = f"{name}.{serial}.{Id}.{sampleNum}.jpg"
            cv2.imwrite(os.path.join("TrainingImage", fn), gray[y:y+h, x:x+w])
            cv2.rectangle(img, (x,y), (x+w,y+h), (255,0,0), 2)
        cv2.imshow('Taking Images', img)
        if cv2.waitKey(100) & 0xFF == ord('q') or sampleNum >= 100:
            break

    cam.release()
    cv2.destroyAllWindows()

    df = pd.read_csv(csv_path)
    df.loc[len(df)] = [serial, Id, name]
    df.to_csv(csv_path, index=False)
    message1.config(text=f"Images Taken for ID {Id}")

# --- Training ---
def getImagesAndLabels(path):
    faceSamples, ids = [], []
    for img_name in os.listdir(path):
        img = Image.open(os.path.join(path, img_name)).convert('L')
        np_img = np.array(img, dtype='uint8')
        serial = int(img_name.split('.')[1])
        faceSamples.append(np_img)
        ids.append(serial)
    return faceSamples, ids

def TrainImages():
    check_haarcascadefile()
    assure_path_exists("TrainingImageLabel")

    recognizer = cv2.face.LBPHFaceRecognizer_create()
    faces, ids = getImagesAndLabels("TrainingImage")
    if not faces:
        mess.showerror('Error', 'No data to train.')
        return

    recognizer.train(faces, np.array(ids))
    recognizer.save(os.path.join("TrainingImageLabel", "Trainner.yml"))
    message1.config(text="Profile Saved Successfully")
    message.config(text=f"Total Registrations: {len(set(ids))}")

# --- Attendance Tracking ---
def TrackImages():
    check_haarcascadefile()
    assure_path_exists("Attendance")
    assure_path_exists("StudentDetails")

    for i in tv.get_children():
        tv.delete(i)

    model_path = os.path.join("TrainingImageLabel", "Trainner.yml")
    if not os.path.isfile(model_path):
        mess.showerror('Error', 'No trained data found')
        return

    recognizer = cv2.face.LBPHFaceRecognizer_create()
    recognizer.read(model_path)
    faceCascade = cv2.CascadeClassifier("haarcascade_frontalface_default.xml")
    df = pd.read_csv(os.path.join("StudentDetails", "StudentDetails.csv"))

    cam = cv2.VideoCapture(0)
    attendance = []

    while True:
        ret, img = cam.read()
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        for (x, y, w, h) in faceCascade.detectMultiScale(gray, 1.2, 5):
            serial, conf = recognizer.predict(gray[y:y+h, x:x+w])
            name = "Unknown"
            if conf < 50:
                row = df[df['SERIAL NO.'] == serial]
                if not row.empty:
                    ID = str(int(row['ID'].values[0]))
                    name = row['NAME'].values[0]
                    ts = datetime.datetime.now().strftime('%d-%m-%Y,%H:%M:%S')
                    attendance.append((ID, name, ts))
            cv2.putText(img, name, (x, y+h), cv2.FONT_HERSHEY_SIMPLEX, 1, (255,255,255), 2)
            cv2.rectangle(img, (x, y), (x+w, y+h), (255,0,0), 2)

        cv2.imshow('Taking Attendance', img)
        if cv2.waitKey(1) == ord('q'):
            break

    cam.release()
    cv2.destroyAllWindows()

    today = datetime.datetime.now().strftime('%d-%m-%Y')
    att_path = os.path.join("Attendance", f"Attendance_{today}.csv")
    with open(att_path, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['ID','NAME','TIMESTAMP'])
        writer.writerows(attendance)

    for ID, name, ts in attendance:
        date_part, time_part = ts.split(',')
        tv.insert('', 'end', text=ID, values=(name, date_part, time_part))

# --- GUI Setup ---
window = tk.Tk()
window.title("Face Recognition Attendance System")
window.geometry('900x650')
window.configure(bg='lightgray')

tk.Label(window, text="Face Recognition Based Attendance System",
         bg="lightgray", fg="black", font=('Helvetica', 20, 'bold')).pack(pady=10)

clock = tk.Label(window, font=('Helvetica', 14), bg='lightgray')
clock.pack()
tick()

# Input Fields
tk.Label(window, text="Enter ID:", bg="lightgray", font=('Helvetica', 12)).place(x=50, y=80)
txt = tk.Entry(window, width=20)
txt.place(x=180, y=80)

tk.Label(window, text="Enter Name:", bg="lightgray", font=('Helvetica', 12)).place(x=50, y=120)
txt2 = tk.Entry(window, width=20)
txt2.place(x=180, y=120)

message1 = tk.Label(window, text="1) Take Images >>> 2) Save Profile", bg="lightgray", fg="blue")
message1.place(x=50, y=160)
message = tk.Label(window, text="", bg="lightgray", fg="green")
message.place(x=50, y=190)

# Buttons
tk.Button(window, text="Take Images", command=TakeImages, width=20, bg='skyblue').place(x=50, y=230)
tk.Button(window, text="Save Profile", command=psw, width=20, bg='lightgreen').place(x=260, y=230)
tk.Button(window, text="Track Attendance", command=TrackImages, width=20, bg='lightyellow').place(x=470, y=230)
tk.Button(window, text="Clear", command=clear_entries, width=20, bg='orange').place(x=50, y=280)
tk.Button(window, text="Change Password", command=change_pass, width=20, bg='red').place(x=260, y=280)
tk.Button(window, text="Contact Us", command=contact, width=20, bg='gray').place(x=470, y=280)

# Treeview for attendance
tv = ttk.Treeview(window, columns=('Name','Date','Time'), show='headings')
tv.column('Name', width=150)
tv.column('Date', width=100)
tv.column('Time', width=100)
tv.heading('Name', text='Name')
tv.heading('Date', text='Date')
tv.heading('Time', text='Time')
tv.place(x=50, y=330)

window.mainloop()
